package com.example.trpg.tool.service;

public class CustomUserDetailsService {
}
