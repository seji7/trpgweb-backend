package com.example.trpg.tool.service;

public interface MemberService {
}
